<?php


echo'


<!--  /*========================================== BODY  ==============================================*/  -->
<body >
<section id="ingreso" class="logcontrolhora">';



echo'
    <h1 class="wow bounce animated bounceInLeft">Registro Envios</h1>
    <div class="loginform">
        <h2>Registro Hora Salida</h2>
        <form action="envio.php" method="post" id="formHoraSal">
            <input type="number" autofocus id="horaSalida" name="horaSalida" value="" placeholder="Hora Salida" required>
             <button type="submit" name = "botonEnvHoraSal" class="btn btn-primary" onclick="" value = "" ><i class="fa fa-arrow-circle-right"></i></button>
            <div class="secenviar">
              
                <div class="clear"></div>
            </div>
                        
        </form>
        <a href=""><button type="button"  class="btn btn-default"> Volver</button></a>
    </div>

    
</section>

</body>
';


