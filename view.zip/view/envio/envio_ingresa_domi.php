<?php


echo'


<!--  /*========================================== BODY  ==============================================*/  -->
<body >
<section id="ingreso" class="logpedido">';


if (isset($_REQUEST['x']))
{
    echo '<div class="alert alert-danger alert-dismissable">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <strong>Envio</strong> ';
    echo ' registrado exitosamente!!!';
    echo'</div>';
}

echo'
    <h1 class="wow bounce animated bounceInLeft">Registro Envios</h1>
    <div class="loginform">
        <h2>Registre el domiciliario</h2>
        <form action="envio.php" method="post" id="formentrar">
            <input type="number" autofocus id="pedido" name="barrasdomiciliario" value="" placeholder="pin domiciliario." required>
             <button type="submit" name = "botonenviodomi" class="btn btn-primary" onclick="capturarDatosPedido()" value = "4" ><i class="fa fa-arrow-circle-right"></i></button>
            <div class="secenviar">
              
                <div class="clear"></div>
            </div>
                        
        </form>
        <a href="controller/restaurantedesdeenvio.php"><button type="button"  class="btn btn-default"> Volver al Restaurante</button></a>
    </div>

    
</section>

</body>
';


