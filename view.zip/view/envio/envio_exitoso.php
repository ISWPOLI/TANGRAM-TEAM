<?php
echo'


<!--  /*========================================== BODY  ==============================================*/  -->
<body >
<section id="ingreso" class="logpedido">

    <h1 class="wow bounce animated bounceInLeft">Registro exitoso</h1>
    
<div class="loginform">
    <div class="container-1">
        <row class="text-center">
            <a class="naranjapcsistel" href="index.php"> Volver a Restaurantes</a><br/>
        </row>
        <row class="text-center">
          <h1></h1><br/><br/><br/>
        </row>
        <row class="text-center">          
            <a class="naranjapcsistel" href="envio.php"> Registrar otro envio</a><br/>
        </row>
    </div>
</div>    
</section>

</body>
';
