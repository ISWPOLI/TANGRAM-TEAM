<?php
session_start();
require_once 'controller/usuario_controller.php';
$control = new UsuarioController();
$control->Mostrarlogin();
exit();
