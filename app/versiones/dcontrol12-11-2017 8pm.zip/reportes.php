<?php
session_start();
/**
 * Created by PhpStorm.
 * User: Dancito
 * Date: 9/10/2017
 * Time: 11:39 PM
 */
require_once 'controller/restaurante_controller.php';
require_once 'controller/usuario_controller.php';
require_once 'controller/rol_controller.php';

$control = new RestauranteController();
$controlusuario = new UsuarioController();
$controlrol = new RolController();

//
/*<li><a href="reportes.php?r=domi">Envios Por Domiciliario</a>
                                        </li>
                                        <li><a href="reportes.php?r=resta">Envios por Restaurantes</a>
                                        </li> */


if (isset($_REQUEST['r']) && $_REQUEST['r'] == 'domi')
{
        $control->reportedomi();
}

if (isset($_REQUEST['r']) && $_REQUEST['r'] == 'resta')
{
    $control->reporteresta();
}