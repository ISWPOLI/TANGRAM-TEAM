<?php
/**
 * Created by PhpStorm.
 * User: Dancito
 * Date: 11/11/2017
 * Time: 9:12 PM
 */
session_start();

require_once 'controller/restaurante_controller.php';
require_once 'controller/usuario_controller.php';
require_once 'controller/rol_controller.php';

$control = new RestauranteController();
$controlusuario = new UsuarioController();
$controlrol = new RolController();

if (isset($_POST['botoneditar']) && $_POST['botoneditar'] == 2)

{
    $controlusuario->model->Load_from_key($_POST['numeroid']); // nombres apellidos identificacion celular empresa
    $controlusuario->model->setNOMBRE($_POST['nombres']);
    $controlusuario->model->setAPELLIDO($_POST['apellidos']);
    $controlusuario->model->setIDENTIFICACION($_POST['identificacion']);
    $controlusuario->model->setCORREO_ELECTRONICO($_POST['correo']);
    $controlusuario->model->setPASSWORD($_POST['password']);
    $controlusuario->model->Save_Active_Row();

}

if (isset($_POST['botoncrear']) && $_POST['botoncrear'] == 3)
{

    $controlusuario->model->setID_ROL(2) ;
    $controlusuario->model->setNOMBRE($_POST['nombres']);
    $controlusuario->model->setAPELLIDO($_POST['apellidos']);
    $controlusuario->model->setIDENTIFICACION($_POST['identificacion']);
    $controlusuario->model->setCORREO_ELECTRONICO($_POST['correo']);
    $controlusuario->model->setPASSWORD($_POST['password']);
    $controlusuario->model->Save_Active_Row_as_New();


}

//
// e editar d eliminar c crear
if (isset($_REQUEST['e']) || isset($_REQUEST['d']) || isset($_REQUEST['c']))
{
    if (isset($_REQUEST['e']))
    {
        $controlusuario->editarsupervisor();
    }
    if (isset($_REQUEST['d']))
    {
        $controlusuario->model->Load_from_key($_REQUEST['d']);
        $controlusuario->model->setID_ROL(99);
        $controlusuario->model->Save_Active_Row();


        header ('Location:supervisores.php');

    }
    if (isset($_REQUEST['c']))
    {
        $controlusuario->crearsupervisor();
    }
}
else
{
    $controlusuario->crudsupervisor();
}
exit();

