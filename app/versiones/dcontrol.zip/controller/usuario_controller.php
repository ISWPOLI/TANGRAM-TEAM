<?php
require_once 'model/tbl_usuario.class.php';

class UsuarioController{
    
    private $model;
    // falta trabajarlo

    public function __CONSTRUCT()
    {
        $this->model = new tbl_usuario();
    }
    
    public function Mostrarlogin(){
        require_once 'view/login/login.php';

    }
    public function home(){
        require_once 'view/header1.php';
        require_once 'view/login/login.php'; //? esta falta actualizarla
        require_once 'view/footer1.php';
    }


}