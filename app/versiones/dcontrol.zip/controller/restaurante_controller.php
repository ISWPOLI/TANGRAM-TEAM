<?php
require_once 'model/tbl_restaurante_class.php';

class RestauranteController{
    
    public $model;
    
    public function __CONSTRUCT()
    {
        $this->model = new tbl_restaurante();
    }
    
    public function Index(){
        require_once 'view/header.php';
        require_once 'view/restaurante/restaurante.php';
        require_once 'view/footer.php';
    }

    public function home(){
        require_once 'view/header1.php';
        require_once 'view/restaurante/restaurante_home.php';
        require_once 'view/footer1.php';
    }


}