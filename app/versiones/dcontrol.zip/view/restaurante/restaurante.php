<?php

echo'
<h1 class="page-header">resataurante</h1>

<div class="well well-sm text-right">
    <h2>escoja el restaurante de su preferencia</h2>
</div>
<form role="form" action="index.php" method="post">
                  <div class="box-body">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Restaurante</label>
                      <select name="recogerestaurante" class="form-control" required>
';
$alm = $this->model->listarrestaurantes();
while ($row = mysqli_fetch_row($alm))
{
    echo '<option value="'.$row[0].'"> '.$row[1].'</option>';
}


echo'
</select>
</div>
<div class="box-footer">
<button name="recogeboton1" type="submit"  class="btn btn-default">Seleccionar</button>

</div>
</form>
    </tbody>
</table> ';
