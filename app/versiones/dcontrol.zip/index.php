<?php

require_once 'controller/restaurante_controller.php';

if (isset($_POST['recogerestaurante']))
    {
        $_SESSION['restaurante_session'] = $_POST['recogerestaurante'];
    }
if (isset( $_SESSION['restaurante_session']))
{
    require_once "controller/restaurante_controller.php";
    $pagina = new RestauranteController();
    $pagina->home();

}
else
{

    require_once 'controller/restaurante_controller.php';
    $pagina = new RestauranteController();
    $pagina->Index();


}