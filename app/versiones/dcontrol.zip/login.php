<?php


require_once 'controller/usuario_controller.php';


 $control = new UsuarioController();
 $control->Mostrarlogin();
 