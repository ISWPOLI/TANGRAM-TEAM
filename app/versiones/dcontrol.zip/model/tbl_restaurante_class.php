<?php

require_once 'databasemysql_class.php';

Class tbl_restaurante {

	private $ID_RESTAURANTE; //int(11)
	private $NOMBRE_SEDE; //varchar(30)
	private $connection;

    public function __CONSTRUCT()
    {
		$this->connection = new DataBaseMysql();
	}

    /**
     * New object to the class. Don�t forget to save this new object "as new" by using the function $class->Save_Active_Row_as_New(); 
     *
     */
	public function New_tbl_restaurante($NOMBRE_SEDE){
		$this->NOMBRE_SEDE = $NOMBRE_SEDE;
	}

    /**
     * Load one row into var_class. To use the vars use for exemple echo $class->getVar_name; 
     *
     * @param key_table_type $key_row
     * 
     */
	public function Load_from_key($key_row){
		$result = $this->connection->RunQuery("Select * from tbl_restaurante where ID_RESTAURANTE = \"$key_row\" ");
		while($row = $result->fetch_array(MYSQLI_ASSOC)){
			$this->ID_RESTAURANTE = $row["ID_RESTAURANTE"];
			$this->NOMBRE_SEDE = $row["NOMBRE_SEDE"];
		}
	}



    /**
     * Delete the row by using the key as arg
     *
     * @param key_table_type $key_row
     *
     */
	public function Delete_row_from_key($key_row){
		$this->connection->RunQuery("DELETE FROM tbl_restaurante WHERE ID_RESTAURANTE = $key_row");
	}

	public function GetKeysOrderBy($column, $order){
		$keys = array(); $i = 0;
		$result = $this->connection->RunQuery("SELECT ID_RESTAURANTE from tbl_restaurante order by $column $order");
			while($row = $result->fetch_array(MYSQLI_ASSOC)){
				$keys[$i] = $row["ID_RESTAURANTE"];
				$i++;
			}
	return $keys;
	}

    public function listarrestaurantes()
    {

        $result = $this->connection->RunQuery("SELECT ID_RESTAURANTE, NOMBRE_SEDE from tbl_restaurante");
        return $result;
    }
    public function nombrerestaurante($a)
    {

        $result = $this->connection->RunQuery("SELECT  NOMBRE_SEDE from tbl_restaurante WHERE ID_RESTAURANTE = '$a'");
        return $result;
    }





	/**
	 * @return ID_RESTAURANTE - int(11)
	 */
	public function getID_RESTAURANTE(){
		return $this->ID_RESTAURANTE;
	}

	/**
	 * @return NOMBRE_SEDE - varchar(30)
	 */
	public function getNOMBRE_SEDE(){
		return $this->NOMBRE_SEDE;
	}

	/**
	 * @param Type: int(11)
	 */
	public function setID_RESTAURANTE($ID_RESTAURANTE){
		$this->ID_RESTAURANTE = $ID_RESTAURANTE;
	}

	/**
	 * @param Type: varchar(30)
	 */
	public function setNOMBRE_SEDE($NOMBRE_SEDE){
		$this->NOMBRE_SEDE = $NOMBRE_SEDE;
	}



    /**
     * Close mysql connection
     */
	public function endtbl_restaurante(){
		$this->connection->CloseMysql();
	}




}