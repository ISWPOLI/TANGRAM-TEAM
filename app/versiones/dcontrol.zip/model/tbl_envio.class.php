<?php
/*
 * Author: Rafael Rocha - www.rafaelrocha.net - info@rafaelrocha.net
 * 
 * Create Date: 1-10-2017
 * 
 * Version of MYSQL_to_PHP: 1.1
 * 
 * License: LGPL 
 * 
 */
require_once 'DataBaseMysql.class.php';

Class tbl_envio {

	private $ID_ENVIO; //int(11)
	private $ID_USUARIO; //int(11)
	private $ID_RESTAURANTE; //int(11)
	private $FECHA_HORA_LLEGADA; //date
	private $FECHA_HORA_SALIDA; //date
	private $connection;

	public function tbl_envio(){
		$this->connection = new DataBaseMysql();
	}

    /**
     * New object to the class. Don�t forget to save this new object "as new" by using the function $class->Save_Active_Row_as_New(); 
     *
     */
	public function New_tbl_envio($ID_USUARIO,$ID_RESTAURANTE,$FECHA_HORA_LLEGADA,$FECHA_HORA_SALIDA){
		$this->ID_USUARIO = $ID_USUARIO;
		$this->ID_RESTAURANTE = $ID_RESTAURANTE;
		$this->FECHA_HORA_LLEGADA = $FECHA_HORA_LLEGADA;
		$this->FECHA_HORA_SALIDA = $FECHA_HORA_SALIDA;
	}

    /**
     * Load one row into var_class. To use the vars use for exemple echo $class->getVar_name; 
     *
     * @param key_table_type $key_row
     * 
     */
	public function Load_from_key($key_row){
		$result = $this->connection->RunQuery("Select * from tbl_envio where ID_ENVIO = \"$key_row\" ");
		while($row = $result->fetch_array(MYSQLI_ASSOC)){
			$this->ID_ENVIO = $row["ID_ENVIO"];
			$this->ID_USUARIO = $row["ID_USUARIO"];
			$this->ID_RESTAURANTE = $row["ID_RESTAURANTE"];
			$this->FECHA_HORA_LLEGADA = $row["FECHA_HORA_LLEGADA"];
			$this->FECHA_HORA_SALIDA = $row["FECHA_HORA_SALIDA"];
		}
	}

    /**
     * Delete the row by using the key as arg
     *
     * @param key_table_type $key_row
     *
     */
	public function Delete_row_from_key($key_row){
		$this->connection->RunQuery("DELETE FROM tbl_envio WHERE ID_ENVIO = $key_row");
	}

    /**
     * Returns array of keys order by $column -> name of column $order -> desc or acs
     *
     * @param string $column
     * @param string $order
     */
	public function GetKeysOrderBy($column, $order){
		$keys = array(); $i = 0;
		$result = $this->connection->RunQuery("SELECT ID_ENVIO from tbl_envio order by $column $order");
			while($row = $result->fetch_array(MYSQLI_ASSOC)){
				$keys[$i] = $row["ID_ENVIO"];
				$i++;
			}
	return $keys;
	}

	/**
	 * @return ID_ENVIO - int(11)
	 */
	public function getID_ENVIO(){
		return $this->ID_ENVIO;
	}

	/**
	 * @return ID_USUARIO - int(11)
	 */
	public function getID_USUARIO(){
		return $this->ID_USUARIO;
	}

	/**
	 * @return ID_RESTAURANTE - int(11)
	 */
	public function getID_RESTAURANTE(){
		return $this->ID_RESTAURANTE;
	}

	/**
	 * @return FECHA_HORA_LLEGADA - date
	 */
	public function getFECHA_HORA_LLEGADA(){
		return $this->FECHA_HORA_LLEGADA;
	}

	/**
	 * @return FECHA_HORA_SALIDA - date
	 */
	public function getFECHA_HORA_SALIDA(){
		return $this->FECHA_HORA_SALIDA;
	}

	/**
	 * @param Type: int(11)
	 */
	public function setID_ENVIO($ID_ENVIO){
		$this->ID_ENVIO = $ID_ENVIO;
	}

	/**
	 * @param Type: int(11)
	 */
	public function setID_USUARIO($ID_USUARIO){
		$this->ID_USUARIO = $ID_USUARIO;
	}

	/**
	 * @param Type: int(11)
	 */
	public function setID_RESTAURANTE($ID_RESTAURANTE){
		$this->ID_RESTAURANTE = $ID_RESTAURANTE;
	}

	/**
	 * @param Type: date
	 */
	public function setFECHA_HORA_LLEGADA($FECHA_HORA_LLEGADA){
		$this->FECHA_HORA_LLEGADA = $FECHA_HORA_LLEGADA;
	}

	/**
	 * @param Type: date
	 */
	public function setFECHA_HORA_SALIDA($FECHA_HORA_SALIDA){
		$this->FECHA_HORA_SALIDA = $FECHA_HORA_SALIDA;
	}

    /**
     * Close mysql connection
     */
	public function endtbl_envio(){
		$this->connection->CloseMysql();
	}

}